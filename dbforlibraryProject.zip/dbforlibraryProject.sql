-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Wersja serwera:               5.5.62-log - MySQL Community Server (GPL)
-- Serwer OS:                    Win64
-- HeidiSQL Wersja:              10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Zrzut struktury bazy danych cyberdata
CREATE DATABASE IF NOT EXISTS `cyberdata` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_polish_ci */;
USE `cyberdata`;

-- Zrzut struktury tabela cyberdata.autor
CREATE TABLE IF NOT EXISTS `autor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imie` varchar(20) COLLATE utf8_polish_ci NOT NULL DEFAULT 'ANONIM',
  `nazwisko` varchar(20) COLLATE utf8_polish_ci NOT NULL DEFAULT 'ANONIM',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.autor: ~10 rows (około)
/*!40000 ALTER TABLE `autor` DISABLE KEYS */;
INSERT INTO `autor` (`id`, `imie`, `nazwisko`) VALUES
	(1, 'William', 'Shakespeare'),
	(2, 'Henryk', 'Sienkiewicz'),
	(3, 'Adam', 'Mickiewicz'),
	(4, 'Eliza', 'Orzeszkowa'),
	(5, 'Jan', 'Kowalski'),
	(8, 'Jacek', 'Woz'),
	(9, 'Bolesław', 'Prus'),
	(11, 'Bolek', 'Niezgoda'),
	(12, 'Bolesław', 'Niezgoda'),
	(13, 'Bolek', 'Zjadliwy');
/*!40000 ALTER TABLE `autor` ENABLE KEYS */;

-- Zrzut struktury tabela cyberdata.autorzy_do_ksiazki
CREATE TABLE IF NOT EXISTS `autorzy_do_ksiazki` (
  `autor_id` int(11) DEFAULT NULL,
  `ksiazka_id` int(11) DEFAULT NULL,
  KEY `FK2ksiazka13` (`ksiazka_id`),
  KEY `FK1Autor12` (`autor_id`),
  CONSTRAINT `FK1Autor12` FOREIGN KEY (`autor_id`) REFERENCES `autor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK2ksiazka13` FOREIGN KEY (`ksiazka_id`) REFERENCES `ksiazki` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.autorzy_do_ksiazki: ~9 rows (około)
/*!40000 ALTER TABLE `autorzy_do_ksiazki` DISABLE KEYS */;
INSERT INTO `autorzy_do_ksiazki` (`autor_id`, `ksiazka_id`) VALUES
	(1, 1),
	(1, 2),
	(2, 3),
	(2, 4),
	(3, 5),
	(4, 6),
	(9, 10),
	(9, 11),
	(9, 11);
/*!40000 ALTER TABLE `autorzy_do_ksiazki` ENABLE KEYS */;

-- Zrzut struktury tabela cyberdata.dziedzina
CREATE TABLE IF NOT EXISTS `dziedzina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nazwa` varchar(150) COLLATE utf8_polish_ci NOT NULL DEFAULT 'INNE',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.dziedzina: ~19 rows (około)
/*!40000 ALTER TABLE `dziedzina` DISABLE KEYS */;
INSERT INTO `dziedzina` (`id`, `nazwa`) VALUES
	(1, 'Literatura polska'),
	(2, 'Literatura zagraniczna'),
	(3, 'Nauki pomocnicze historii'),
	(4, 'Historia'),
	(5, 'Nauki społeczne (ekonomia, socjologia)'),
	(6, 'Nauki polityczne'),
	(7, 'Prawo'),
	(8, 'Wojskowość'),
	(9, 'Dzieła treści ogólnej (wielodziedzinowe encyklopedie, informatory)'),
	(10, 'Bibliotekoznastwo, bibliologia, bibliografie ogólne'),
	(11, 'Informacja Naukowa'),
	(12, 'Filozofia, Teologia, Religia'),
	(13, 'Geografia, Archeologia, Etnologia, Folklor, Sport'),
	(14, 'Edukacja'),
	(15, 'Literaturoznawstwo, Literatura, Teatr, Kino, Telewizja, Dziennikarstwo'),
	(16, 'Matematyka, Informatyka, Fizyka, Chemia, Geologia, Nauki biologiczne'),
	(17, 'Medycyna'),
	(18, 'Rolnictwo, Leśnictwo'),
	(19, 'Technika');
/*!40000 ALTER TABLE `dziedzina` ENABLE KEYS */;

-- Zrzut struktury tabela cyberdata.ksiazka_do_user
CREATE TABLE IF NOT EXISTS `ksiazka_do_user` (
  `ksiazka_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  KEY `FK1ksiazka` (`ksiazka_id`),
  KEY `FK2user` (`user_id`),
  CONSTRAINT `FK2user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK1ksiazka` FOREIGN KEY (`ksiazka_id`) REFERENCES `ksiazki` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.ksiazka_do_user: ~1 rows (około)
/*!40000 ALTER TABLE `ksiazka_do_user` DISABLE KEYS */;
INSERT INTO `ksiazka_do_user` (`ksiazka_id`, `user_id`) VALUES
	(6, 6);
/*!40000 ALTER TABLE `ksiazka_do_user` ENABLE KEYS */;

-- Zrzut struktury tabela cyberdata.ksiazki
CREATE TABLE IF NOT EXISTS `ksiazki` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tytul` varchar(60) COLLATE utf8_polish_ci NOT NULL DEFAULT 'Brak tytułu',
  `wydawnictwo` varchar(50) COLLATE utf8_polish_ci DEFAULT NULL,
  `dostepna` int(11) NOT NULL DEFAULT '1',
  `dziedzina_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1dziedzina` (`dziedzina_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.ksiazki: ~9 rows (około)
/*!40000 ALTER TABLE `ksiazki` DISABLE KEYS */;
INSERT INTO `ksiazki` (`id`, `tytul`, `wydawnictwo`, `dostepna`, `dziedzina_id`) VALUES
	(1, 'Hamlet', 'AAA', 1, 2),
	(2, 'Makbet', 'AAA', 1, 2),
	(3, 'Potop', 'BBB', 1, 1),
	(4, 'Quo vadis', 'BBB', 1, 1),
	(5, 'Pan Tadeusz', 'CCC', 1, 1),
	(6, 'Nad Niemnem', 'CCC', 0, 1),
	(8, 'Jak zgłodniałem na polu.', 'Moja wieś', 1, 1),
	(10, 'Lalka tom 2', 'Świat Książki', 1, 1),
	(11, 'Lalka tom 1', 'Świat Książki', 1, 1);
/*!40000 ALTER TABLE `ksiazki` ENABLE KEYS */;

-- Zrzut struktury tabela cyberdata.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL,
  `role` varchar(255) COLLATE utf8_polish_ci NOT NULL DEFAULT 'USER',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.roles: ~2 rows (około)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `role`) VALUES
	(1, 'ROLE_ADMIN'),
	(2, 'ROLE_USER');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Zrzut struktury tabela cyberdata.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imie` varchar(50) COLLATE utf8_polish_ci NOT NULL DEFAULT 'Gal',
  `nazwisko` varchar(50) COLLATE utf8_polish_ci NOT NULL DEFAULT 'Anonim',
  `aktywny` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8_polish_ci NOT NULL DEFAULT '0',
  `haslo` varchar(255) COLLATE utf8_polish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.user: ~3 rows (około)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `imie`, `nazwisko`, `aktywny`, `email`, `haslo`) VALUES
	(6, 'Miro', 'Maro', 1, 'miroandmaro@mm.com', '$2a$10$SxquIri5b/DxljOyxcHfd.Pa/VSIUzd2q/zyyTJdavTrr07H1OVLy'),
	(7, 'Kinga', 'Prom', 1, 'kingap@mm.com', '$2a$10$uDoZW765qgpH6EYHkVMLOOA/8tkYK3Nl8yyAGWzz34apMIxadeKJK'),
	(9, 'Milena', 'Maren', 1, 'milenka@mm.com', '$2a$10$zkckxb06MNfoqH41K4P3N.VmgfvMlSZGHVlENM0EcRKeKyi8dxhcK');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- Zrzut struktury tabela cyberdata.userroles
CREATE TABLE IF NOT EXISTS `userroles` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `roleid` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`userid`,`roleid`),
  KEY `FK2roleid` (`roleid`),
  CONSTRAINT `FK2roleid` FOREIGN KEY (`roleid`) REFERENCES `roles` (`id`),
  CONSTRAINT `FK1userCon` FOREIGN KEY (`userid`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- Zrzucanie danych dla tabeli cyberdata.userroles: ~2 rows (około)
/*!40000 ALTER TABLE `userroles` DISABLE KEYS */;
INSERT INTO `userroles` (`userid`, `roleid`) VALUES
	(6, 1),
	(7, 2);
/*!40000 ALTER TABLE `userroles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
